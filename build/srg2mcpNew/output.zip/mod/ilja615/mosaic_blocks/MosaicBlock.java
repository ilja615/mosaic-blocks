package mod.ilja615.mosaic_blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.Item;
import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.block.AbstractBlock.Properties;

public class MosaicBlock extends HorizontalBlock
{
    public static final EnumProperty COLOR = EnumProperty.create("color", MosaicColor.class);

    public MosaicBlock(Properties properties)
    {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(COLOR, MosaicColor.WHITE));
    }

    protected void createBlockStateDefinition(StateContainer.Builder<Block, BlockState> builder) {
        builder.add(FACING, COLOR);
    }

    public BlockState getStateForPlacement(BlockItemUseContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public ActionResultType use(BlockState state, World worldIn, BlockPos pos, PlayerEntity player, Hand handIn, BlockRayTraceResult hit)
    {
        if (state.hasProperty(COLOR) && !worldIn.isClientSide) {
            if (MosaicColor.isDyeItem(player.getItemInHand(handIn).getItem())) {
                if (MosaicColor.DYE_COLOR_MAP.get(player.getItemInHand(handIn).getItem().getRegistryName().toString()) != state.getValue(COLOR)) {
                    worldIn.setBlock(pos, state.setValue(COLOR, MosaicColor.DYE_COLOR_MAP.get(player.getItemInHand(handIn).getItem().getRegistryName().toString())), 3);
                    if (worldIn.random.nextFloat() < (Config.DYE_CONSUME_CHANCE.get() / 100.0f) && !player.isCreative()) {
                        player.getItemInHand(handIn).shrink(1);
                        worldIn.playSound(null, pos, SoundEvents.AXE_STRIP, SoundCategory.BLOCKS, 0.5f, 1.0F);
                        for(int i = 0; i < 7; ++i) {
                            double d0 = worldIn.random.nextGaussian() * 0.02D;
                            double d1 = worldIn.random.nextGaussian() * 0.02D;
                            double d2 = worldIn.random.nextGaussian() * 0.02D;
                            ((ServerWorld)worldIn).sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D, 1,  d0, d1, d2, 0d);
                        }
                    } else {
                        worldIn.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundCategory.BLOCKS, 0.5f, 1.0F);
                    }
                }
                return ActionResultType.SUCCESS;
            }
        }
        return super.use(state, worldIn, pos, player, handIn, hit);
    }

    @Override
    public BlockState updateShape(BlockState stateIn, Direction facing, BlockState facingState, IWorld worldIn, BlockPos currentPos, BlockPos facingPos)
    {
        if (stateIn.hasProperty(COLOR) && !worldIn.isClientSide())
        {
            if (facingState.getBlock() == Blocks.WET_SPONGE)
                return stateIn.setValue(COLOR, MosaicColor.WHITE);
        }
        return super.updateShape(stateIn, facing, facingState, worldIn, currentPos, facingPos);
    }

    @Override
    public boolean hasAnalogOutputSignal(BlockState state)
    {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState blockState, World worldIn, BlockPos pos)
    {
        if (blockState.hasProperty(COLOR))
        {
            return ((MosaicColor)blockState.getValue(COLOR)).getIndexNumber();
        }
        return 0;
    }
}
